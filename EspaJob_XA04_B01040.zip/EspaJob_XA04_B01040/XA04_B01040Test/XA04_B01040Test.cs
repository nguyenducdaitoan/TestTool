﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Data;
using System.Collections;

#region custom lib
using Jp.Co.Unisys.Espa.Job.XA04_B01040;
using Jp.Co.Unisys.EFSA.Job.Entity;
using Jp.Co.Unisys.EFSA.Core.Transaction;
using Jp.Co.Unisys.EFSA.Core.AOP;
using Jp.Co.Unisys.EFSA.Core.Context;
using System.Diagnostics;
using Jp.Co.Unisys.EFSA.Job.Base;
#endregion

namespace XA04_B01040Test
{
    [TestClass]
    public class XA04_B01040Test
    {
        [TestInitialize()]
        public void TestInitialize()
        {
            Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current = new Jp.Co.Unisys.EFSA.Core.Context.EFSAContext();
        }

        [TestCleanup()]
        public void TestCleanup()
        {

        }

        [TestMethod]
        public void T_XA04_B01040_001_001()
        {
            string dataNo = "";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040JobBs();
            Type interfaceType = typeof(IXA04_B01040JobBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();

            IXA04_B01040JobBs iXA04_B01040JobBs = (IXA04_B01040JobBs)TransparentProxyFactory.CreateTransparentProxy(
            target,
            interfaceType,
            new TestLib.Level1TestInterceptor(target.GetType().Name,
                          classSummary,
                          methodSummary,
                          TestLib.Util.GetParameterFromJobParameterEntity(jobParameterEntity)
                  )
            );

            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040JobBs.JobMain(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }

            if (endStatus != "050")
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            ErrorMessage = TestLib.Util.GetAppLogERR();
            if (ErrorMessage != "")
            {
                Console.WriteLine(ErrorMessage);
            }
            else
            {
                Assert.Fail();
            }

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }


        }
        [TestMethod]
        public void T_XA04_B01040_001_002()
        {
            string dataNo = "";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040JobBs();
            Type interfaceType = typeof(IXA04_B01040JobBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();

            IXA04_B01040JobBs iXA04_B01040JobBs = (IXA04_B01040JobBs)TransparentProxyFactory.CreateTransparentProxy(
            target,
            interfaceType,
            new TestLib.Level1TestInterceptor(target.GetType().Name,
                          classSummary,
                          methodSummary,
                          TestLib.Util.GetParameterFromJobParameterEntity(jobParameterEntity)
                  )
            );

            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040JobBs.JobMain(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }

            if (endStatus != "050")
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            ErrorMessage = TestLib.Util.GetAppLogERR();
            if (ErrorMessage != "")
            {
                Console.WriteLine(ErrorMessage);
            }
            else
            {
                Assert.Fail();
            }

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }


        }
        [TestMethod]
        public void T_XA04_B01040_001_003()
        {
            string dataNo = "";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040JobBs();
            Type interfaceType = typeof(IXA04_B01040JobBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();

            IXA04_B01040JobBs iXA04_B01040JobBs = (IXA04_B01040JobBs)TransparentProxyFactory.CreateTransparentProxy(
            target,
            interfaceType,
            new TestLib.Level1TestInterceptor(target.GetType().Name,
                          classSummary,
                          methodSummary,
                          TestLib.Util.GetParameterFromJobParameterEntity(jobParameterEntity)
                  )
            );

            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040JobBs.JobMain(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }

            if (endStatus != "050")
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            ErrorMessage = TestLib.Util.GetAppLogERR();
            if (ErrorMessage != "")
            {
                Console.WriteLine(ErrorMessage);
            }
            else
            {
                Assert.Fail();
            }

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }


        }
        [TestMethod]
        public void T_XA04_B01040_001_004()
        {
            string dataNo = "";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("");


            Object target = new XA04_B01040JobBs();
            Type interfaceType = typeof(IXA04_B01040JobBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();

            IXA04_B01040JobBs iXA04_B01040JobBs = (IXA04_B01040JobBs)TransparentProxyFactory.CreateTransparentProxy(
            target,
            interfaceType,
            new TestLib.Level1TestInterceptor(target.GetType().Name,
                          classSummary,
                          methodSummary,
                          TestLib.Util.GetParameterFromJobParameterEntity(jobParameterEntity)
                  )
            );

            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040JobBs.JobMain(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }

            if (endStatus != "050")
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            ErrorMessage = TestLib.Util.GetAppLogERR();
            if (ErrorMessage != "")
            {
                Console.WriteLine(ErrorMessage);
            }
            else
            {
                Assert.Fail();
            }

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }


        }
        [TestMethod]
        public void T_XA04_B01040_001_005()
        {
            string dataNo = "D005";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            dsWXA04_B01040.Tables[0].Rows.Add(new object[] { "XA04_B01040CreateCSVTemporaryTable1", "0", "1", "0,000000000000001,20121220,00000000000001,123.05,12345.70,1519139.00,6152501.00,-4633362.00", });
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "BOT", "[STP_XA04_InsWXA04_B01040] Bắt đầu xử lý", "TESTUSER", "", "XA04_B01040", });
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：1 record     ", "TESTUSER", "", "XA04_B01040", });
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "EOT", "[STP_XA04_InsWXA04_B01040] Kết thúc xử lý", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_001_006()
        {
            string dataNo = "D006";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVFile"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVFile(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "02", "03", "20121220", "1", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_001_007()
        {
            string dataNo = "D019";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVFile"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVFile(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "02", "01", "10000000000002", "10000000000000000002", "20121115", "100000000000002", "000000000000002", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000002", "10000000000000000002", "20121115", "100000000000002", "00000000000001", "123.0500", "50000.0000", "6152501.0000", "000000000000002", "1519139.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            dsWXA04_B01040.Tables[0].Rows.Add(new object[] { "XA04_B01040CreateCSVTemporaryTable1", "0", "1", "0,000000000000001,20121220,00000000000001,123.05,12345.70,1519139.00,6152501.00,-4633362.00", });
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：1 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_001_008()
        {
            string dataNo = "D020";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVFile"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVFile(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000002", "10000000000000000002", "20121115", "100000000000002", "000000000000002", "01", "03", "20121220", "01", "0", });
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000005", "10000000000000000005", "20121118", "100000000000003", "000000000000001", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000002", "10000000000000000002", "20121115", "100000000000002", "00000000000001", "123.0500", "50000.0000", "6152501.0000", "000000000000002", "1519139.0000", "0", });
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000005", "10000000000000000005", "20121118", "100000000000003", "00000000000001", "145.0300", "42512.2500", "45216.7500", "000000000000001", "4960001.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            dsWXA04_B01040.Tables[0].Rows.Add(new object[] { "XA04_B01040CreateCSVTemporaryTable1", "0", "1", "0,000000000000001,20121220,00000000000001,123.05,12345.70,1519139.00,6152501.00,-4633362.00", });
            dsWXA04_B01040.Tables[0].Rows.Add(new object[] { "XA04_B01040CreateCSVTemporaryTable1", "0", "2", "1,000000000000002,20121220,00000000000001,123.05,50000.00,6152501.00,1519139.00,4633362.00", });
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：2 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_001()
        {
            string dataNo = "D006";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "02", "03", "20121220", "1", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_002()
        {
            string dataNo = "D007";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "04", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_003()
        {
            string dataNo = "D008";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121221", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_004()
        {
            string dataNo = "D009";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "02", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_005()
        {
            string dataNo = "D010";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "1", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_006()
        {
            string dataNo = "D011";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "02", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_007()
        {
            string dataNo = "D012";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "02", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_008()
        {
            string dataNo = "D013";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000002", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_009()
        {
            string dataNo = "D014";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000002", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_010()
        {
            string dataNo = "D015";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121117", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_011()
        {
            string dataNo = "D016";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000002", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_012()
        {
            string dataNo = "D017";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000002", "6152501.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_013()
        {
            string dataNo = "D018";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "1", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：0 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_014()
        {
            string dataNo = "D019";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "02", "01", "10000000000002", "10000000000000000002", "20121115", "100000000000002", "000000000000002", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000002", "10000000000000000002", "20121115", "100000000000002", "00000000000001", "123.0500", "50000.0000", "6152501.0000", "000000000000002", "1519139.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            dsWXA04_B01040.Tables[0].Rows.Add(new object[] { "XA04_B01040CreateCSVTemporaryTable1", "0", "1", "0,000000000000001,20121220,00000000000001,123.05,12345.70,1519139.00,6152501.00,-4633362.00", });
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：1 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_015()
        {
            string dataNo = "D020";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000002", "10000000000000000002", "20121115", "100000000000002", "000000000000002", "01", "03", "20121220", "01", "0", });
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000005", "10000000000000000005", "20121118", "100000000000003", "000000000000001", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000002", "10000000000000000002", "20121115", "100000000000002", "00000000000001", "123.0500", "50000.0000", "6152501.0000", "000000000000002", "1519139.0000", "0", });
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000005", "10000000000000000005", "20121118", "100000000000003", "00000000000001", "145.0300", "42512.2500", "45216.7500", "000000000000001", "4960001.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            dsWXA04_B01040.Tables[0].Rows.Add(new object[] { "XA04_B01040CreateCSVTemporaryTable1", "0", "1", "0,000000000000001,20121220,00000000000001,123.05,12345.70,1519139.00,6152501.00,-4633362.00", });
            dsWXA04_B01040.Tables[0].Rows.Add(new object[] { "XA04_B01040CreateCSVTemporaryTable1", "0", "2", "1,000000000000002,20121220,00000000000001,123.05,50000.00,6152501.00,1519139.00,4633362.00", });
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：2 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_016()
        {
            string dataNo = "D021";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000002", "10000000000000000002", "20121115", "100000000000002", "000000000000002", "01", "03", "20121220", "01", "0", });
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000005", "10000000000000000005", "20121118", "100000000000003", "000000000000001", "01", "03", "20121220", "01", "0", });
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000009", "10000000000000000009", "20121112", "100000000000006", "000000000000001", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000002", "10000000000000000002", "20121115", "100000000000002", "00000000000001", "123.0500", "50000.0000", "6152501.0000", "000000000000002", "1519139.0000", "0", });
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000005", "10000000000000000005", "20121118", "100000000000003", "00000000000001", "145.0300", "42512.2500", "45216.7500", "000000000000001", "4960001.0000", "0", });
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000009", "10000000000000000009", "20121112", "100000000000006", "00000000000002", "187.0600", "87565.0000", "15426.1400", "000000000000001", "1519139.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            dsWXA04_B01040.Tables[0].Rows.Add(new object[] { "XA04_B01040CreateCSVTemporaryTable1", "0", "1", "0,000000000000001,20121220,00000000000001,123.05,12345.70,1519139.00,6152501.00,-4633362.00", });
            dsWXA04_B01040.Tables[0].Rows.Add(new object[] { "XA04_B01040CreateCSVTemporaryTable1", "0", "2", "0,000000000000001,20121220,00000000000001,145.03,42512.25,45216.75,4960001.00,-4914784.25", });
            dsWXA04_B01040.Tables[0].Rows.Add(new object[] { "XA04_B01040CreateCSVTemporaryTable1", "0", "3", "1,000000000000001,20121220,00000000000002,187.06,87565.00,15426.14,1519139.00,-1503712.86", });
            dsWXA04_B01040.Tables[0].Rows.Add(new object[] { "XA04_B01040CreateCSVTemporaryTable1", "0", "4", "1,000000000000002,20121220,00000000000001,123.05,50000.00,6152501.00,1519139.00,4633362.00", });
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：4 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }
        [TestMethod]
        public void T_XA04_B01040_002_017()
        {
            string dataNo = "D019";

            #region Init
            TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\common.sql");
            if (!dataNo.Equals(string.Empty))
            {
                TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + ".sql");
            }
            #endregion

            JobParameterEntity jobParameterEntity = new JobParameterEntity();
            jobParameterEntity.JobNetCd = "0";
            jobParameterEntity.JobSeq = 1;
            jobParameterEntity.JobCd = "XA04_B01040";
            jobParameterEntity.TerminalName = "Server";
            jobParameterEntity.PrintKbn = "1";
            jobParameterEntity.PrinterName = "";
            jobParameterEntity.ListServerKbn = "";
            jobParameterEntity.TantoCd = "TestUser";
            jobParameterEntity.JobStartMode = "1";
            jobParameterEntity.OnlineBatchKbn = "2";
            jobParameterEntity.ControlDate = TestLib.Util.GetBatchDate();
            jobParameterEntity.ListKbn = "01";
            jobParameterEntity.SubSystemKbn = "XA";
            jobParameterEntity.CommitCount = 10;
            jobParameterEntity.ExeParaArray = new ArrayList();
            jobParameterEntity.ExeParaArray.Add("01");
            jobParameterEntity.ExeParaArray.Add("20121220");
            jobParameterEntity.ExeParaArray.Add("03");
            jobParameterEntity.ExeParaArray.Add("1");


            Object target = new XA04_B01040CtlBs();
            Type interfaceType = typeof(IXA04_B01040CtlBs);
            Hashtable classSummary = new Hashtable();
            Hashtable methodSummary = new Hashtable();
            methodSummary["CreateCSVTemporaryTable"] = "";

            IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)TransparentProxyFactory.CreateTransparentProxy(
                target,
                interfaceType,
                new Level2Interceptor(target.GetType().Name,
                              classSummary,
                              methodSummary,
                              jobParameterEntity));


            String endStatus = String.Empty;
            try
            {
                endStatus = iXA04_B01040CtlBs.CreateCSVTemporaryTable(jobParameterEntity);
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Commit();
            }
            catch
            {
                Jp.Co.Unisys.EFSA.Core.Context.EFSAContext.Current.Transaction.Rollback();
                throw;
            }
            if (endStatus != JobConstant.JOBENDSTS.NORMALEND)
            {
                Assert.Fail("Trạng thái: " + endStatus);
            }

            string ErrorMessage = TestLib.Util.GetLogWRN_ERR();
            if (ErrorMessage != "") Assert.Fail(ErrorMessage);

            if (!dataNo.Equals(string.Empty))
            {
                #region Init
                if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql"))
                {
                    TestLib.Util.ExecuteSQLFromFile(AppDomain.CurrentDomain.BaseDirectory + @"\sql\" + dataNo + "_AFTER.sql");
                }
                #endregion
            }

            #region result TChokuboJohoOya
            DataSet dsTChokuboJohoOya = new DataSet();
            dsTChokuboJohoOya.Tables.Add("TChokuboJohoOya");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KaishaCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("ShitenCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("LCNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("BLNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("NyukaHI");
            dsTChokuboJohoOya.Tables[0].Columns.Add("InvoiceNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTChokuboJohoOya.Tables[0].Columns.Add("GinkoKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TsukaTaniCD");
            dsTChokuboJohoOya.Tables[0].Columns.Add("TegataKijitu");
            dsTChokuboJohoOya.Tables[0].Columns.Add("KessaiShoriKBN");
            dsTChokuboJohoOya.Tables[0].Columns.Add("DelFlg");
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "000000000000001", "01", "03", "20121220", "01", "0", });
            dsTChokuboJohoOya.Tables[0].Rows.Add(new object[] { "02", "01", "10000000000002", "10000000000000000002", "20121115", "100000000000002", "000000000000002", "01", "03", "20121220", "01", "0", });
            string resultdsTChokuboJohoOya = TestLib.Util.CompareTwoDataset(dsTChokuboJohoOya, TestLib.Util.GetDataFromTable("TChokuboJohoOya"));
            if (resultdsTChokuboJohoOya != "")
            {
                Assert.Fail(resultdsTChokuboJohoOya);
            }
            #endregion
            #region result TGinkoSeiriNO
            DataSet dsTGinkoSeiriNO = new DataSet();
            dsTGinkoSeiriNO.Tables.Add("TGinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KaishaCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("ShitenCD");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("LCNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("BLNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("NyukaHI");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("InvoiceNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("YoyakuNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiOpenRATE");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiGaikaKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("KessaiKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("GinkoSeiriNO");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("EnKansanKIN");
            dsTGinkoSeiriNO.Tables[0].Columns.Add("DelFlg");
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000001", "10000000000000000001", "20121116", "100000000000001", "00000000000001", "123.0500", "12345.7000", "1519139.0000", "000000000000001", "6152501.0000", "0", });
            dsTGinkoSeiriNO.Tables[0].Rows.Add(new object[] { "01", "01", "10000000000002", "10000000000000000002", "20121115", "100000000000002", "00000000000001", "123.0500", "50000.0000", "6152501.0000", "000000000000002", "1519139.0000", "0", });
            string resultdsTGinkoSeiriNO = TestLib.Util.CompareTwoDataset(dsTGinkoSeiriNO, TestLib.Util.GetDataFromTable("TGinkoSeiriNO"));
            if (resultdsTGinkoSeiriNO != "")
            {
                Assert.Fail(resultdsTGinkoSeiriNO);
            }
            #endregion
            #region result WXA04_B01040
            DataSet dsWXA04_B01040 = new DataSet();
            dsWXA04_B01040.Tables.Add("WXA04_B01040");
            dsWXA04_B01040.Tables[0].Columns.Add("JOBUNIQ");
            dsWXA04_B01040.Tables[0].Columns.Add("FileNo");
            dsWXA04_B01040.Tables[0].Columns.Add("GyoNo");
            dsWXA04_B01040.Tables[0].Columns.Add("CSVData");
            dsWXA04_B01040.Tables[0].Rows.Add(new object[] { "XA04_B01040CreateCSVTemporaryTable1", "0", "1", "0,000000000000001,20121220,00000000000001,123.05,12345.70,1519139.00,6152501.00,-4633362.00", });
            string resultdsWXA04_B01040 = TestLib.Util.CompareTwoDataset(dsWXA04_B01040, TestLib.Util.GetDataFromTable("WXA04_B01040"));
            if (resultdsWXA04_B01040 != "")
            {
                Assert.Fail(resultdsWXA04_B01040);
            }
            #endregion
            #region result FW_DBLog
            DataSet dsFW_DBLog = new DataSet();
            dsFW_DBLog.Tables.Add("FW_DBLog");
            dsFW_DBLog.Tables[0].Columns.Add("LogKbn");
            dsFW_DBLog.Tables[0].Columns.Add("HostName");
            dsFW_DBLog.Tables[0].Columns.Add("LogId1");
            dsFW_DBLog.Tables[0].Columns.Add("LogId2");
            dsFW_DBLog.Tables[0].Columns.Add("LogId3");
            dsFW_DBLog.Tables[0].Columns.Add("LogId4");
            dsFW_DBLog.Tables[0].Columns.Add("MessageKbn");
            dsFW_DBLog.Tables[0].Columns.Add("ErrMsg");
            dsFW_DBLog.Tables[0].Columns.Add("RegisterUserCd");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateWinMod");
            dsFW_DBLog.Tables[0].Columns.Add("UpdateJobMod");
            dsFW_DBLog.Tables[0].Rows.Add(new object[] { "JOB", "", "XA04_B01040", "", "", "", "INS", "0--[STP_XA04_InsWXA04_B01040] Số record đăng kí：1 record     ", "TESTUSER", "", "XA04_B01040", });
            string resultdsFW_DBLog = TestLib.Util.CompareTwoDatasetWithRowCount(dsFW_DBLog, TestLib.Util.GetDataFromTable("FW_DBLog"));
            if (resultdsFW_DBLog != "")
            {
                Assert.Fail(resultdsFW_DBLog);
            }
            #endregion

        }

    }
}