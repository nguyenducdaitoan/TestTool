﻿#region using
//Net framework
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Collections;
//EFSA
using Jp.Co.Unisys.EFSA.Job.Base;
using Jp.Co.Unisys.EFSA.Job.Entity;
using Jp.Co.Unisys.EFSA.Core.Transaction;
using Jp.Co.Unisys.Espa.Util.Job;
using Jp.Co.Unisys.Espa.Constants;
#endregion
namespace Jp.Co.Unisys.Espa.Job.XA04_B01040
{
    public class XA04_B01040CtlBs:JobBaseLevel2,IXA04_B01040CtlBs
    {
        #region khai báo hằng
        private const string JOBUNIQ_METHODNAME = "CreateCSVTemporaryTable";
        private const string FILENO = "0";
        private const string BCP_METHODNAME = "CreateCSVFile";
        private const string REQUIRED_KBN = "RequiredKbn=1";
        #region khai báo code running
        private const string MSG_FAILURE = "MSG_J00013";
        private const string MSG_PARA_INACCURACY = "MSG_J00014";
        private const string MSG_ERROR_PROCESS = "MSG_J00015";
        #endregion
        #region khai báo thông báo
        private const string MSGSTR_STATIC_PARA_CTRL = "Static parameter control";
        private const string MSGSTR_CLASS_SUMMARY = "DSDKQT";
        #endregion

        #region khai báo tên method
        private const string METHOD_MAKE_TABLE="CreateCSVTemporaryTable";
        private const string METHOD_MAKE_FILE="CreateCSVFile";
        private const string METHOD_MAKE_TABLE_SUMMARY="Xử lý đăng kí data vào bảng tạm Danh sách đăng kí xác định quyết toán(CSV)";
        private const string METHOD_MAKE_FILE_SUMMARY="Xử lý tạo File Danh sách đăng kí xác định quyết toán(CSV)";

        #endregion

        #endregion 

      
        public XA04_B01040CtlBs()
        {
            ClassSummary[this.GetType().Name] = MSGSTR_CLASS_SUMMARY;
            MethodSummary[METHOD_MAKE_TABLE] = METHOD_MAKE_TABLE_SUMMARY;
            MethodSummary[METHOD_MAKE_FILE] = METHOD_MAKE_FILE_SUMMARY;
        }
  
        public string CreateCSVTemporaryTable(JobParameterEntity level2JobParameterEntity)
        {
            EFSASqlCommand sqlCommand=base.GetEFSASqlCommand(level2JobParameterEntity);
            string prmStrJobUniq=string.Empty;
            string prmStrFileNo=string.Empty;
            string prmStrGinkoKBN=string.Empty;
            string prmStrTegataKijitu=string.Empty;
            string prmStrTsukaTaniCD=string.Empty;
            string prmStrKessaiShoriKBN=string.Empty;
            prmStrJobUniq=level2JobParameterEntity.JobCd.Trim()+JOBUNIQ_METHODNAME+level2JobParameterEntity.JobSeq.ToString().Trim();
            prmStrFileNo=FILENO;
            prmStrGinkoKBN=Convert.ToString(level2JobParameterEntity.ExeParaArray[0]).Trim();
            prmStrTegataKijitu=Convert.ToString(level2JobParameterEntity.ExeParaArray[1]).Trim();
            prmStrTsukaTaniCD=Convert.ToString(level2JobParameterEntity.ExeParaArray[2]).Trim();
            prmStrKessaiShoriKBN=Convert.ToString(level2JobParameterEntity.ExeParaArray[3]).Trim();
            sqlCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@JOBUNIQ",System.Data.SqlDbType.VarChar,60));
            sqlCommand.Parameters["@JOBUNIQ"].Direction=System.Data.ParameterDirection.Input;
            sqlCommand.Parameters["@JOBUNIQ"].Value=prmStrJobUniq;
            sqlCommand.Parameters.Add(new System.Data.SqlClient.SqlParameter("@FileNO",System.Data.SqlDbType.Int,4));
            sqlCommand.Parameters["@FileNo"].Direction = System.Data.ParameterDirection.Input;
            sqlCommand.Parameters["@FileNo"].Value = prmStrFileNo;
            sqlCommand.Parameters.Add( new System.Data.SqlClient.SqlParameter( "@GinkoKBN", System.Data.SqlDbType.Char, 2 ) );
            sqlCommand.Parameters["@GinkoKBN"].Direction = System.Data.ParameterDirection.Input;
            sqlCommand.Parameters["@GinkoKBN"].Value = prmStrGinkoKBN;
            sqlCommand.Parameters.Add( new System.Data.SqlClient.SqlParameter( "@TegataKijitu", System.Data.SqlDbType.Char, 8 ) );
            sqlCommand.Parameters["@TegataKijitu"].Direction = System.Data.ParameterDirection.Input;
            sqlCommand.Parameters["@TegataKijitu"].Value = prmStrTegataKijitu;
            sqlCommand.Parameters.Add( new System.Data.SqlClient.SqlParameter( "@TsukaTaniCD", System.Data.SqlDbType.Char, 2 ) );
            sqlCommand.Parameters["@TsukaTaniCD"].Direction = System.Data.ParameterDirection.Input;
            sqlCommand.Parameters["@TsukaTaniCD"].Value = prmStrTsukaTaniCD;
            sqlCommand.Parameters.Add( new System.Data.SqlClient.SqlParameter( "@KessaiShoriKBN", System.Data.SqlDbType.Char, 2 ) );
            sqlCommand.Parameters["@KessaiShoriKBN"].Direction = System.Data.ParameterDirection.Input;
            sqlCommand.Parameters["@KessaiShoriKBN"].Value = prmStrKessaiShoriKBN;

            sqlCommand.CommandText="exec [STP_XA04_InsWXA04_B01040] @JOBUNIQ, @FileNO,  @GinkoKBN,  @TegataKijitu,@TsukaTaniCD,@KessaiShoriKBN	, @UserCD, @UpdateJobMod, @Success OUTPUT, @ErrCode OUTPUT, @ErrMsg OUTPUT";
            return base.ExecSpEFSASqlCommand(sqlCommand,level2JobParameterEntity);
        }
        public string CreateCSVFile(JobParameterEntity level2JobParameterEntity)
        {
            string endStatus = string.Empty;
            string dbName = string.Empty; 
            string outputPath = string.Empty; 
            string fileName = string.Empty;
            Console.WriteLine("Bat dau");
            JobUtility jobUtility = new JobUtility();
            dbName = jobUtility.GetDatabaseName();
            Console.WriteLine("Ten database"+dbName);
            //outputPath = DirUtilJob.GetFolderPath( APPara.SPara.FOLDERPATH.CSVFOLDERPATH);
            outputPath = "D:\\";
            Console.WriteLine(outputPath);
            //fileName = DirUtilJob.GetFileName( level2JobParameterEntity, BCP_METHODNAME, DirUtilJob.CSVFilePattern.CSVOut );
            fileName = "DSDKQT.csv";
            Console.WriteLine(fileName);
            string jobUniq = level2JobParameterEntity.JobCd.Trim() + JOBUNIQ_METHODNAME + level2JobParameterEntity.JobSeq.ToString().Trim();
            Console.WriteLine(jobUniq);
            string strQuery = " SELECT CSVData FROM [" + dbName + "].[dbo].[WXA04_B01040]";
            strQuery += " WHERE JOBUNIQ = '" + jobUniq + "' ";
            strQuery += " AND   FileNo  = " + FILENO;
            strQuery += " ORDER BY GyoNo";
             jobUtility.CreateZeroByteFile = true;
             Console.WriteLine(strQuery);
             Console.WriteLine("Type:"+this.GetType().Name);
             Console.WriteLine("MethodName:"+MethodInfo.GetCurrentMethod().Name);
             endStatus = jobUtility.BCPOut("XA04_B01040CtlBs.CreateCSVFile",fileName,
                             strQuery, level2JobParameterEntity ,outputPath);
            Console.WriteLine("ket thuc:"+endStatus);
            return endStatus;
        }
        public override void Validation(string abc,ArrayList exeParaArray)
        {
           
        }
    }
}
