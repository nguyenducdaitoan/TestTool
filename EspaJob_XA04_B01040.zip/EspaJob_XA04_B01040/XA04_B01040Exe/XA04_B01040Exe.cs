﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using Jp.Co.Unisys.EFSA.Job.Entity;
using Jp.Co.Unisys.EFSA.Job.Base;
using Jp.Co.Unisys.Espa.Job.XA04_B01040;

namespace XA04_B01040
{
    class XA04_B01040Exe : JobBaseExe
    {
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                ClassSummary[Process.GetCurrentProcess().ProcessName] = "DSDKQT";
                IXA04_B01040JobBs iXA04_B01040JobBs = (IXA04_B01040JobBs)GetLevel1Instance(new XA04_B01040JobBs(), typeof(IXA04_B01040JobBs));
                JobParameterEntity jobParameterEntity = new JobParameterEntity();
                string endStatus = iXA04_B01040JobBs.JobMain(jobParameterEntity);
                SetExitCode(endStatus);
            }
            catch (Exception)
            {                
                SetErrorExitCode();
            }
        }
    }
}
