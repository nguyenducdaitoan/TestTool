﻿#region using
//Microsoft.NET framework
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
//EFSA framework
using Jp.Co.Unisys.EFSA.Core.ExceptionManagement;
using Jp.Co.Unisys.EFSA.Core.Utility;
using Jp.Co.Unisys.EFSA.Job.Base;
using Jp.Co.Unisys.EFSA.Job.Entity;
#endregion
namespace Jp.Co.Unisys.Espa.Job.XA04_B01040
{
    public class XA04_B01040JobBs:JobBaseLevel1,IXA04_B01040JobBs
    {
        #region định nghĩa biến
            private JobParameterEntity level2JobParameterEntity = null;
        #endregion

        #region định nghĩa hằng
            private const string MSGSTR_CLASS_SUMMARY="DSDKQT";
            private const string MSG_INPUT_ERR = "MSG_J00014";
        #endregion

        #region constructor
            public XA04_B01040JobBs()
            {
                ClassSummary[this.GetType().Name]=MSGSTR_CLASS_SUMMARY;
                MethodSummary["JobMain"]=MSGSTR_CLASS_SUMMARY;
            }
        #endregion

        #region Xử lý tạo danh sách đăng ký xác định quyết toán (Level 1)
            public string JobMain(JobParameterEntity level1JobParameterEntity)
            {
                #region khai báo biến trả về
                    string endstatus=String.Empty;
                #endregion
                JobUtility jobUtility=new JobUtility();
                IXA04_B01040CtlBs iXA04_B01040CtlBs = (IXA04_B01040CtlBs)GetLevel2Instance(new XA04_B01040CtlBs(), typeof(IXA04_B01040CtlBs), level1JobParameterEntity);
                #region tạo bảng tạm
                    level2JobParameterEntity=jobUtility.GetLevel2Entity(level1JobParameterEntity,0,1,2,3);
                    endstatus=iXA04_B01040CtlBs.CreateCSVTemporaryTable(level2JobParameterEntity);
                    Console.WriteLine("ket qua 1:"+endstatus);
                #endregion

                #region tạo file csv
                    level2JobParameterEntity=jobUtility.GetLevel2Entity(level1JobParameterEntity);
                    endstatus = iXA04_B01040CtlBs.CreateCSVFile(level2JobParameterEntity);
                    Console.WriteLine("ket qua 2:" + endstatus);
                #endregion
                return endstatus;
            
            
            }
        #endregion

        #region check parameter
            public override void Validation(ArrayList jobExeParameter)
            {
                if (!ValidationCheckUtil.IsValidation(jobExeParameter[0], "RequiredKbn=1"))
                {
                    throw new AppException(this, MethodBase.GetCurrentMethod(), MSG_INPUT_ERR, "Ngan hang");
                }
                if (!ValidationCheckUtil.IsValidation(jobExeParameter[1], "RequiredKbn=1"))
                {
                    throw new AppException(this, MethodBase.GetCurrentMethod(), MSG_INPUT_ERR, "Ngay xu ly");
                }
                if (!ValidationCheckUtil.IsValidation(jobExeParameter[2], "RequiredKbn=1"))
                {
                    throw new AppException(this, MethodBase.GetCurrentMethod(), MSG_INPUT_ERR, "Don vi tien te");
                }
                if (!ValidationCheckUtil.IsValidation(jobExeParameter[3], "RequiredKbn=1"))
                {
                    throw new AppException(this, MethodBase.GetCurrentMethod(), MSG_INPUT_ERR, "Tinh trang xu ly quyet toan");
                }
            }
        #endregion           
        
    }
}
