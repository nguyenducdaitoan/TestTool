﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Jp.Co.Unisys.EFSA.Job.Entity;
namespace Jp.Co.Unisys.Espa.Job.XA04_B01040
{
    public interface IXA04_B01040CtlBs
    {
        string CreateCSVTemporaryTable(JobParameterEntity level2JobParameterEntity);
        string CreateCSVFile(JobParameterEntity level2JobParameterEntity);
    }
}
